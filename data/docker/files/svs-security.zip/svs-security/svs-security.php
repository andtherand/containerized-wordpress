<?php
/*
Plugin Name: SVS Security
Plugin URI: svs-security
Description: Removes unnecessary clutter from WPHead.
Version: 1.0.0
Author: Andy Ruck.
*/
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wp_shortlink_wp_head');
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');